# My Fitness Tracker

A personal fitness accountability app built around four tabs: Today, Workouts, Progress and History.

## Current V0.1 features
- Blush / sage / burgundy visual system
- Daily habit tracking: workout, steps, water, calories, sleep, medications
- Editable workout templates
- Ad-hoc workout creation
- Workout completion tracking
- Persistent local storage
- Progress photo selection and local photo references
- Wedding countdown to 29 May 2027
- Weekly workout target of 4–5 sessions

## Run it
1. Install Node.js (LTS) and Expo CLI tooling.
2. Run `npm install`.
3. Run `npx expo start`.
4. Open with Expo Go on an iPhone or Android phone, or use an emulator.

The next production step is to add proper photo storage/backups, richer set/rep/weight logging, authentication, and cloud sync.
